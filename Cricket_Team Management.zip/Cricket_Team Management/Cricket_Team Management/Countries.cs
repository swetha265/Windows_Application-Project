﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cricket_Team_Management
{
    public partial class Countries : Form
    {
        public Countries()
        {
            InitializeComponent();
        }

        private void lbladd_Click(object sender, EventArgs e)
        {
            Add_Country ob = new Add_Country();
            ob.Show();
            this.Hide();
        }

        private void lbldelete_Click(object sender, EventArgs e)
        {
            Delete_Country ob = new Delete_Country();
            ob.Show();
            this.Hide();
        }

        private void lbldisplay_Click(object sender, EventArgs e)
        {
            Display_Country ob = new Display_Country();
            ob.Show();
            this.Hide();
        }
    }
}
