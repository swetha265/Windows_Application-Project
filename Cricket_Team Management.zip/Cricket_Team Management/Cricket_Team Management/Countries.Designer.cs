﻿namespace Cricket_Team_Management
{
    partial class Countries
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Countries));
            this.lbladd = new System.Windows.Forms.Label();
            this.lbldelete = new System.Windows.Forms.Label();
            this.lbldisplay = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbladd
            // 
            this.lbladd.AutoSize = true;
            this.lbladd.Location = new System.Drawing.Point(58, 47);
            this.lbladd.Name = "lbladd";
            this.lbladd.Size = new System.Drawing.Size(109, 17);
            this.lbladd.TabIndex = 0;
            this.lbladd.Text = "ADD COUNTRY";
            this.lbladd.Click += new System.EventHandler(this.lbladd_Click);
            // 
            // lbldelete
            // 
            this.lbldelete.AutoSize = true;
            this.lbldelete.Location = new System.Drawing.Point(58, 101);
            this.lbldelete.Name = "lbldelete";
            this.lbldelete.Size = new System.Drawing.Size(134, 17);
            this.lbldelete.TabIndex = 1;
            this.lbldelete.Text = "DELETE COUNTRY";
            this.lbldelete.Click += new System.EventHandler(this.lbldelete_Click);
            // 
            // lbldisplay
            // 
            this.lbldisplay.AutoSize = true;
            this.lbldisplay.Location = new System.Drawing.Point(58, 163);
            this.lbldisplay.Name = "lbldisplay";
            this.lbldisplay.Size = new System.Drawing.Size(137, 17);
            this.lbldisplay.TabIndex = 2;
            this.lbldisplay.Text = "DISPLAY COUNTRY";
            this.lbldisplay.Click += new System.EventHandler(this.lbldisplay_Click);
            // 
            // Countries
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbldisplay);
            this.Controls.Add(this.lbldelete);
            this.Controls.Add(this.lbladd);
            this.Name = "Countries";
            this.Text = "Countries";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbladd;
        private System.Windows.Forms.Label lbldelete;
        private System.Windows.Forms.Label lbldisplay;
    }
}